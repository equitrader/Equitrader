RPC Port: 43102
Network Port: 43103